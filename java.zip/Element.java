package com.example.alarmapp;

import android.util.Log;

import java.text.DateFormat;
import java.util.Calendar;


//Klasse med navn element. Element objektet lagre alt informationerne når en notifikation laves.
public class Element {

    //Definerer variabler der skal kunne lagres
    String food;
    String note;
    Calendar timeForAlarm;
    Calendar timeMade;
    String originalFood;
    boolean clicked;
    int id;

    //Constructor funktion. Denne skal bruges hvis man vil lave et nyt element objekt. Der defineres hvilke oplysninger elementet skal have
    Element(String givenFood, String givenNote, Calendar givenTime, int givenId, Calendar givenTimeMade) {
        food = givenFood;
        originalFood = givenFood;
        note = givenNote;
        timeForAlarm = givenTime;
        id = givenId;
        timeMade = givenTimeMade;
    }

    //En masse funktioner der gør det muligt at hente informationer fra det enkelte objekt

    public String getFoodString() {
        return food;
    }

    public String getOriginalFoodString() {
        return originalFood;
    }

    public String getNoteString() {
        return note;
    }

    public void changeFoodString(String text) {
        food = text;
    }

    public long getTimeForAlarm() {
        return timeForAlarm.getTimeInMillis();
    }

    public long getTimeMade() {
        return timeMade.getTimeInMillis();
    }

    public int getId() {
        return id;
    }

    public int getProgress(){
        Calendar timeNowC = Calendar.getInstance();

        long timeMadel = getTimeMade();
        long timeForAlarml = getTimeForAlarm();
        long timeNowl = timeNowC.getTimeInMillis();

        long progress = ((100 / (timeForAlarml - timeMadel)) * (timeNowl - timeMadel));
        Log.d("adter", "" + progress);

        return (int) progress;

    }

    public String getTimeText() {
        String timeText = DateFormat.getTimeInstance(DateFormat.SHORT).format(timeForAlarm.getTime());
        return timeText;
    }

    public String getDateText() {
        String dateText = DateFormat.getDateInstance().format(timeForAlarm.getTime());
        return dateText;
    }

}
