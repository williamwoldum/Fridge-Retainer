package com.example.alarmapp;


//Importerer ekstra kode (libraries)
import android.app.AlarmManager;
        import android.app.DatePickerDialog;
        import android.app.PendingIntent;
        import android.app.TimePickerDialog;
        import android.content.Context;
        import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TextInputLayout;
        import android.support.v4.app.DialogFragment;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
        import android.widget.DatePicker;
        import android.widget.TextView;
        import android.widget.TimePicker;
        import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.DateFormat;
        import java.util.ArrayList;
        import java.util.Calendar;

//Laver klasse AfterIntro
public class AfterIntro extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {


    //Laver en masse Variabler (Status, objekttype, navn)
    private TextInputLayout foodInput;
    private TextInputLayout noteInput;
    private Button timeSelector;
    private Button dateSelector;
    private Button listOpener;
    private Button notiCreator;
    private Calendar timeForAlarm;
    private Calendar timeMade;

    //Statiske variabler fordi de skal bruges til individueller objekter senere
    private static String food;
    private static String note;
    private static int id;
    private static int firstId;


    //Laver to nye Arraylist (indeholdende objekt, navn)
    public static ArrayList<Element> ElementsForList;
    public static ArrayList<Element> ElementsForAlarm;

    //-------------------------------------------------------------------------------------------

    //onCreates køres når denne aktivitet åbnes (AfterIntro)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afterintro);


        //Definerer hvilke Views de før lavede variabler tilhører
        foodInput = findViewById(R.id.food_Input);
        noteInput = findViewById(R.id.note_Input);
        timeSelector = findViewById(R.id.timeDisplayer);
        dateSelector = findViewById(R.id.dateDisplayer);
        listOpener = findViewById(R.id.listButton);
        notiCreator = findViewById(R.id.notiCreator);
        ElementsForList = new ArrayList<>();
        ElementsForAlarm = new ArrayList<>();
        timeForAlarm = Calendar.getInstance();
        timeMade = Calendar.getInstance();


        //Laver "klik"-lytere på forskellige Views
        dateSelector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });

        timeSelector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });

        listOpener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AfterIntro.this, RecyclerActivity.class);
                startActivity(intent);
            }
        });

        notiCreator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmInputAndSetAlarm();
                saveData();
            }
        });


        //Indlæser listedata fra sidste gang gemt
        loadData();

    }

    //-------------------------------------------------------------------------------------------

    //Laver tidspunkt for notifikation efter dato er valgt
    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        timeForAlarm.set(Calendar.YEAR, year);
        timeForAlarm.set(Calendar.MONTH, month);
        timeForAlarm.set(Calendar.DAY_OF_MONTH, day);

        //Opdatere teksten på datovælgeren efter tidspunkt er fundet
        updateDateText();

    }

    //-------------------------------------------------------------------------------------------

    //Laver tidspunkt for notifikation efter tid er valgt
    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        timeForAlarm.set(Calendar.HOUR_OF_DAY, hourOfDay);
        timeForAlarm.set(Calendar.MINUTE, minute);
        timeForAlarm.set(Calendar.SECOND, 0);

        //Opdatere teksten på tidsvælgeren efter tidspunkt er fundet
        updateTimeText();
    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at ændre tidstekst efter tid er valgt
    private void updateTimeText() {
        //Gemmer det valgte tidspunkt i en string (tekst variabel)
        String timeText = DateFormat.getTimeInstance(DateFormat.SHORT).format(timeForAlarm.getTime());

        timeSelector.getLayoutParams().width = 400;
        timeSelector.requestLayout();
        //Ændre teksten på tidsvælgeren til den valgte tid
        timeSelector.setText(timeText);
    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at ændre tidstekst efter tid er valgt
    private void updateDateText() {
        //Gemmer den valgte dato i en string (tekst variabel)
        String currentDateString = DateFormat.getDateInstance(DateFormat.SHORT).format(timeForAlarm.getTime());

        dateSelector.getLayoutParams().width = 700;
        dateSelector.requestLayout();
        //Ændre teksten på datovælgeren til den valgte dato
        dateSelector.setText(currentDateString);
    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at starte notifikation
    private void startAlarm() {

        //Lav toast kort besked der vises på skærm
        Toast.makeText(this, "Notification added to list", Toast.LENGTH_SHORT).show();

        //Definerer variabel timeMade med tidspunktet notifikationen laves (altså nu)
        timeMade = Calendar.getInstance();

        //Laver et id til notifikationen med den tid vi har lige nu i millisekunder
        id = (int) System.currentTimeMillis();

        //Definere long variabel med tidspunktet hvor notifikationen skal komme
        long timeForAlarmLong = timeForAlarm.getTimeInMillis();

        //Tilføjer et nyt objekt til begge arraylister (madtype, note, tidspunkt for notifikation, id, tidspunkt notifikationen blev lavet)
        ElementsForList.add(new Element(food, note, timeForAlarm, id, timeMade));
        ElementsForAlarm.add(new Element(food, note, timeForAlarm, id, timeMade));

        //Laver notifikation med samme Id som det objekt vi lige har tilført til arraysene
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        intent.putExtra("requestCode", id);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, id, intent, 0);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeForAlarmLong, pendingIntent);
        timeForAlarm = Calendar.getInstance();

    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at give Notifikationslaveren id'et fra det objekt der først skal komme en notifikation med oplysninger fra
    public static int getId() {

        //Algoritme til at sortere arrayet med kommende notifikationer således at den der først skal notifiseres er først
        Element tempElement;
        for (int i = 0; i < ElementsForAlarm.size(); i++) {
            if (i < ElementsForAlarm.size() - 1) {
                if (ElementsForAlarm.get(i).getTimeForAlarm() > ElementsForAlarm.get(i + 1).getTimeForAlarm()) {
                    tempElement = ElementsForAlarm.get(i);
                    ElementsForAlarm.add(tempElement);
                    ElementsForAlarm.remove(i);

                    i = 0;
                }
            }
        }
        firstId = ElementsForAlarm.get(0).getId();

        //Retunerer id'et på det objekt der næste gang skal notifiseres om
        return firstId;
    }

    //-------------------------------------------------------------------------------------------

        //Funktion til at chekke om food input feltet og det valgte tidspunkt kan bruges
    private boolean validateFood() {

        //Får hvad der står i de to inputfelter
        food = foodInput.getEditText().getText().toString().trim();


        //Giver en error hvis food inputfeltet er tomt
        if (food.isEmpty() ) {
            foodInput.setError("Field can't be empty");
            return false;
        }

        //Hvis ingen af de overnævnte ting er rigtige så lav ingen errors og validateFoodAndTime retunerer true
        else {
            foodInput.setError(null);
            return true;
        }
    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at chekke om note input feltet kan bruges
    private boolean validateNote() {
        //Får hvad der står i note inputfeltet
        note = noteInput.getEditText().getText().toString().trim();

        //Chekker om noten er mere end 20 tegn hvis den er så lav en error
        if (note.length() > 20) {
            noteInput.setError("Note too long");
            return false;
        }

        //Hvis den overnævnte betingelse ikke er rigtig så lav ingen errors og validateNote retunerer true
        else {
            noteInput.setError(null);
            return true;
        }
    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at chekke om note input feltet kan bruges
    private boolean validateTime() {

        //Giver en error hvis det valgte tidspunkt er i fortiden
        if (timeForAlarm.before(Calendar.getInstance())) {
            Toast.makeText(this, "Selected time must be in the future!", Toast.LENGTH_SHORT).show();
            return false;
        }

        //Hvis den overnævnte betingelse ikke er rigtig så lav ingen errors og validateNote retunerer true
        else {
            return true;
        }
    }

    //-------------------------------------------------------------------------------------------

    //Funktion til at sikre sig at både food, tidspunktet og noten er valideret til true (godkendt)
    public void confirmInputAndSetAlarm() {
        if (!validateFood()|!validateNote()|!validateTime()) {
            return;
        }

        //Hvis begge er true så start en notifikation
        startAlarm();
    }

    //_________________________________________________________________________

    //Loader gemt data i bagrunden til listen
    public void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        Type type = new TypeToken<ArrayList<Element>>() {}.getType();
        AfterIntro.ElementsForList = gson.fromJson(json, type);

        if (AfterIntro.ElementsForList == null) {
            AfterIntro.ElementsForList = new ArrayList<>();
        }
    }

    //_________________________________________________________________________

    //Gemmer nuværende listeindhold i Google gson
    private void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(AfterIntro.ElementsForList);
        editor.putString("task list", json);
        editor.apply();
    }

}
