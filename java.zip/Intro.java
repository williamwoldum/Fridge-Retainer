package com.example.alarmapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

//Klassen til vores intro aktivitet laves
public class Intro extends AppCompatActivity {

    //Laver en timer. Kalder den timer
    Timer timer;

    //Aktiviteten skabes
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);


        //Gør således at timeren køre i 2000 millisekunder (2 sek) inden den skifter til aktiviteten "AfterIntro"
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(Intro.this, AfterIntro.class);
                startActivity(intent);
                finish();
            }
        }, 2000);
    }
}