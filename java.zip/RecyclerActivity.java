package com.example.alarmapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.Calendar;

//Laver klasse til recyclerview aktivitet (liste med kort med objekt information)
public class RecyclerActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private TextView goBack;
    private boolean clicked = false;

//_________________________________________________________________________

    //Køres når aktiviteten åbnes
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        goBack = findViewById(R.id.goBack);

        //Trykker man på "Go Back" kommer man tilbage til aktiviteten "AfterIntro"
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecyclerActivity.this, AfterIntro.class);
                saveData();
                startActivity(intent);
            }
        });

        //Laver listen
        buildRecyclerView();

    }

    //_________________________________________________________________________

    //Gemmer nuværende listeindhold i Google gson
    private void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(AfterIntro.ElementsForList);
        editor.putString("task list", json);
        editor.apply();
    }

    //_________________________________________________________________________

    //Funktion til at aflyse bestemt notifikation (Kræver id på notifikation)
    public void cancelAlarm(int specificId) {

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, specificId, intent, 0);

        alarmManager.cancel(pendingIntent);
    }

    //_________________________________________________________________________

    //Funktion til at Fjerne kort fra liste
    public void removeItem(int position) {
        Toast.makeText(this, "Notification canceled", Toast.LENGTH_SHORT).show();
        int id = AfterIntro.ElementsForList.get(position).getId();
        for(int i = 0; i < AfterIntro.ElementsForAlarm.size(); i++){
            if (id == AfterIntro.ElementsForAlarm.get(position).getId()){
                cancelAlarm(id);
                AfterIntro.ElementsForAlarm.remove(position);
                break;
            }

        }
        AfterIntro.ElementsForList.remove(position);
        mAdapter.notifyItemRemoved(position);
    }

    //_________________________________________________________________________

    //Funktion til at ændre kort på liste (lige nu ændres food titlen til clicked når kortet trykkes på
    public void changeItem(int position){

        if (!clicked) {
            AfterIntro.ElementsForList.get(position).changeFoodString("Clicked");
            mAdapter.notifyItemChanged(position);
            clicked = true;
        }

        else if (clicked){
            AfterIntro.ElementsForList.get(position).changeFoodString(AfterIntro.ElementsForList.get(position).getOriginalFoodString());
            mAdapter.notifyItemChanged(position);
            clicked = false;
        }
    }

    //_________________________________________________________________________

    //Funktion til at laver listen ved hjælp af adpater klassen
    public void buildRecyclerView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(AfterIntro.ElementsForList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                    changeItem(position);
            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });
    }

    //_________________________________________________________________________


    //Funktion til søge mekanisme
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                mAdapter.getFilter().filter(s);
                return false;
            }
        });
        return true;
    }

    //_________________________________________________________________________



}
