package com.example.alarmapp;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;

import java.util.Calendar;


//Klasse til lave pop op dato vælger
public class DatePickerFragment extends DialogFragment {
    @NonNull
    @Override

    //pop op vinduet kaldes
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        //Indlæser den nuværeende tid i kalender objektet c
        Calendar c = Calendar.getInstance();

        //Tager år måned og dag fra c og indstiller pop op kalenderen efter det
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        //Pop op vinduet laves
        return new DatePickerDialog(getActivity(), (DatePickerDialog.OnDateSetListener) getActivity(), year, month, day);
    }
}
