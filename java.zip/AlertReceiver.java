package com.example.alarmapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

//Laver en notifikationsmodtager klasse
public class AlertReceiver extends BroadcastReceiver {

    //Funktion der bygger en notifikation når den modtager data. Notifikationsmodtageren bygger en notifikation med et specifikt  given id
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = AfterIntro.getId();
        NotificationHelper notificationHelper = new NotificationHelper(context);
        NotificationCompat.Builder nb = notificationHelper.getChannelNotification();
        notificationHelper.getManager().notify(id, nb.build());
    }
}