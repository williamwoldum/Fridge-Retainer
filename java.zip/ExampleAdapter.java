package com.example.alarmapp;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

//Tak til Youtubekanalen "Coding in Flow" for inspirationen til denne recycleview adapter der kan gøre det muligt at scrolle
//i vores liste uden at skulle loade


//_________________________________________________________________________

public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> implements Filterable {
    private ArrayList<Element> mExampleListFull;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onDeleteClick(int position);
    }

    //_________________________________________________________________________

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    //_________________________________________________________________________

    public static class ExampleViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextView1;
        public TextView mTextView2;
        public TextView mTextView3;
        public TextView mTextView4;
        public ProgressBar mBar;
        public ImageView mDeleteImage;

        //_________________________________________________________________________

        public ExampleViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);

            mTextView1 = itemView.findViewById(R.id.textView);
            mTextView2 = itemView.findViewById(R.id.textView2);
            mTextView3 = itemView.findViewById(R.id.textView3);
            mTextView4 = itemView.findViewById(R.id.textView4);
            mBar = itemView.findViewById(R.id.progressBar);
            mDeleteImage = itemView.findViewById(R.id.image_delete);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

            mDeleteImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onDeleteClick(position);
                        }
                    }
                }
            });
        }
    }

    //_________________________________________________________________________

    public ExampleAdapter(ArrayList<Element> exampleList) {
        AfterIntro.ElementsForList = exampleList;
        mExampleListFull = new ArrayList<>(AfterIntro.ElementsForList);
    }

    //_________________________________________________________________________

    @Override
    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.example_item, parent, false);
        ExampleViewHolder evh = new ExampleViewHolder(v, mListener);
        return evh;
    }

    //_________________________________________________________________________

    @Override
    public void onBindViewHolder(ExampleViewHolder holder, int position) {
        Element currentItem = AfterIntro.ElementsForList.get(position);

        int random = (int)(Math.random() * 100 + 1);

        //Log.d("adter", "" + progress);
        //Log.d("adter", "" + timeMade);



        holder.mTextView1.setText(currentItem.getFoodString());
        holder.mTextView2.setText(currentItem.getNoteString());
        holder.mTextView3.setText(currentItem.getTimeText());
        holder.mTextView4.setText(currentItem.getDateText());
        holder.mBar.setProgress(random);
    }

    //_________________________________________________________________________

    @Override
    public int getItemCount() {
        return AfterIntro.ElementsForList.size();
    }

    //_________________________________________________________________________

    @Override
    public Filter getFilter() {
        return mExapleFilter;
    }

    //_________________________________________________________________________

    private Filter mExapleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            ArrayList<Element> filteredList = new ArrayList<>();

            if (charSequence == null || charSequence.length() == 0){
                filteredList.addAll(mExampleListFull);
            } else {
                String filterPattern = charSequence.toString().toLowerCase().trim();

                for(Element item : mExampleListFull){
                    if (item.getFoodString().toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            AfterIntro.ElementsForList.clear();
            AfterIntro.ElementsForList.addAll((ArrayList) filterResults.values);
            notifyDataSetChanged();
        }
    };

    //_________________________________________________________________________
}