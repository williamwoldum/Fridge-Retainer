package com.example.alarmapp;

import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

//Notifikations hjælper klasse til at bestemme hvad notifkationen skal indeholde
public class NotificationHelper extends ContextWrapper {

    //Laver kanal id og navn. Vigtigt for nye android styresystemer. Bruger skal kunne vælge specifkke kanaltyper fra
    public static final String channelID = "channelID";
    public static final String channelName = "Channel Name";
    private String foodString;
    private String noteString;
    private NotificationManager mManager;

    //Funktion til at lave kanal hvis styresystemet er nyere end "Oreo"
    public NotificationHelper(Context base) {
        super(base);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createChannel();
        }
    }

    //Laver kanal hvis styresystem er nyrere end Oreo
    @TargetApi(Build.VERSION_CODES.O)
    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channel);
    }

    //Lave ren notifikations manager til at time og lave notifikationer (køre automatisk i baggrunden)
    public NotificationManager getManager() {
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }


    //Indsætter data i notifikation
    public NotificationCompat.Builder getChannelNotification() {

        Intent intent = new Intent(getApplicationContext(), AfterIntro.class); // Here pass your activity where you want to redirect.

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent contentIntent = PendingIntent.getActivity(this, (int) (Math.random() * 100), intent, 0);


        //Algoritme til at finde objekt med id'et som skal laves en notifikation med først
        foodString = AfterIntro.ElementsForAlarm.get(0).getFoodString();
        noteString = AfterIntro.ElementsForAlarm.get(0).getNoteString();
        AfterIntro.ElementsForAlarm.remove(0);


        //Dette skal notifikation indeholde hvis note stringen er tom
        if (noteString.isEmpty()) {
            return new NotificationCompat.Builder(getApplicationContext(), channelID)
                    .setContentTitle("Bummer, your " + foodString + " may be too old")
                    .setSmallIcon(R.drawable.ic_one)
                    .setColor(Color.BLUE)
                    .setContentIntent(contentIntent);
        }

        //Dette skal notifikationen indeholde hvis note stregen ikk er tom
        else {
            return new NotificationCompat.Builder(getApplicationContext(), channelID)
                    .setContentTitle("Bummer, your " + foodString + " may be too old...")
                    .setContentText("Note: " + noteString)
                    .setSmallIcon(R.drawable.ic_one)
                    .setColor(Color.BLUE)
                    .setContentIntent(contentIntent);

        }
    }

}